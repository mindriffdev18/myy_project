# django-countrycodes

A Django app to manage country names and codes.

## Installation

```bash
pip install django-countrycodes
